print.poicla <- function(x,...){
  if(is.null(x$rhos) && is.null(x$rho)){
    if(!is.null(x[[1]]$alpha)) cat("Value of alpha used to transform data: ", x[[1]]$alpha, fill=TRUE)
    if(is.null(x[[1]]$alpha)) cat("No transformation performed.", fill=TRUE)
    cat("Type of normalization performed: ", x[[1]]$type, fill=TRUE)
    cat("Number of training observations: ", nrow(x[[1]]$x), fill=TRUE)
    if(!is.null(x[[1]]$xte)) cat("Number of test observations: ", nrow(x[[1]]$xte), fill=TRUE)
    cat("Number of features: ", ncol(x[[1]]$x), fill=TRUE)
    cat("-------------------------", fill=TRUE)
    cat("-------------------------", fill=TRUE)
    for(i in 1:length(x)){
      cat("-------------------------", fill=TRUE)
      cat("Value of rho used: ", x[[i]]$rho, fill=TRUE)
      cat("Number of features used in classifier: ", sum(apply(x[[i]]$ds!=1, 2, sum)!=0), fill=TRUE)
      if(sum(apply(x[[i]]$ds!=1, 2, sum)!=0)<100) cat("Indices of features used in classifier: ", which(apply(x[[i]]$ds!=1, 2, sum)!=0), fill=TRUE)
    }
  } else {
    if(!is.null(x$alpha)) cat("Value of alpha used to transform data: ", x$alpha, fill=TRUE)
    if(is.null(x$alpha)) cat("No transformation performed.", fill=TRUE)
    cat("Type of normalization performed: ", x$type, fill=TRUE)
    cat("Number of training observations: ", nrow(x$x), fill=TRUE)
    if(!is.null(x$xte)) cat("Number of test observations: ", nrow(x$xte), fill=TRUE)
    cat("Number of features: ", ncol(x$x), fill=TRUE)
    cat("Value of rho used: ", x$rho, fill=TRUE)
    cat("Number of features used in classifier: ", sum(apply(x$ds!=1, 2, sum)!=0), fill=TRUE)
    if(sum(apply(x$ds!=1, 2, sum)!=0)<100) cat("Indices of features used in classifier: ", which(apply(x$ds!=1, 2, sum)!=0), fill=TRUE)
  }
}
