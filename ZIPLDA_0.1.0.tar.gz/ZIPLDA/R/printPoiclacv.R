print.poiclacv <- function(x,...){
  if(!is.null(x$alpha)) cat("Value of alpha used to transform data: ", x$alpha, fill=TRUE)
  if(is.null(x$alpha)) cat("No transformation performed.",fill=TRUE)
  cat("Rho values considered: ", round(x$rhos,3), fill=TRUE)
  cat("Number of CV folds performed: ", length(x$folds), fill=TRUE)
  cat("Type of normalization performed: ", x$type, fill=TRUE)
  nnonzero.mean <- round(apply(x$nnonzero, 2, mean),3)
  err.mean <- round(apply(x$errs, 2, mean),3)
  cat(fill=TRUE)
  cat("CV results:", fill=TRUE)
  mat <- cbind(round(x$rhos,3), err.mean,nnonzero.mean)
  mat <- rbind(c("Rho", "Errors", "Num. Nonzero Features"), mat)
  write.table(mat, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
}
