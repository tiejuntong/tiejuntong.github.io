Soft <- function(x,a){
  return(sign(x)*pmax(abs(x)-a,0))
}
