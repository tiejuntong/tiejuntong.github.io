#estimate probablity of 0
estp<-function(x){
  G<-length(x[1,])
  num0<-apply(x==0,1,sum)
  probp<-apply(exp(-x),1,sum)-num0
  p<-(num0-probp)/(G-probp)
  p[num0<probp]<-0
  return(p)
}
