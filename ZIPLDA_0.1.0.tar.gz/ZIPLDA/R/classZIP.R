classZIP<-function(x,y,xte=NULL,beta=1,prob=NULL,prob0=NULL,type=c("mle","deseq","quantile"), prior=NULL, transform=TRUE, alpha=NULL){
  if(is.null(xte)){
    xte <- x
    warning("Since no xte was provided, testing was performed on training data set.")
  }
  type <- match.arg(type)
  if(!transform && !is.null(alpha)) stop("You have asked for NO transformation but have entered alpha.")
  if(transform && is.null(alpha)) alpha <- FindBestTransform(x)
  if(transform){
    if(alpha<=0 || alpha>1) stop("alpha must be between 0 and 1")
    x <- x^alpha
    xte <- xte^alpha
  }
  if(is.null(prior)) prior <- rep(1/length(unique(y)), length(unique(y)))
  null.out <- NullModel(x, type=type)
  ns <- null.out$n
  nste <- NullModelTest(null.out,x,xte,type=type)$nste
  uniq <- sort(unique(y))
  signx<-sign(xte==0)
  if(is.null(prob0)){
    ds <- GetDn(ns,x,y,beta)
    discriminant <- matrix(NA, nrow=nrow(xte), ncol=length(uniq))
    for(k in 1:length(uniq)){
      discriminant[,k] <- rowSums(scale(xte,center=FALSE,scale=(1/log(ds[k,])))) - rowSums(scale(nste,center=FALSE,scale=(1/ds[k,]))) + log(prior[k])
    }
    save <- list(ns=ns,nste=nste,ds=ds,discriminant=discriminant,ytehat=uniq[apply(discriminant,1,which.max)], alpha=alpha,x=x,y=y,xte=xte,alpha=alpha,type=type)
    class(save) <- "poicla"
    return(save)
  }else{
    ds<- GetDn(ns,x,y, beta)
    discriminant <- matrix(NA, nrow=nrow(xte), ncol=length(uniq))
    discriminant1 <- matrix(NA, nrow=nrow(xte), ncol=length(uniq))
    #discriminant[,k] <- rowSums(scale(xte,center=FALSE,scale=(1/log(ds[k,])))) - rowSums(scale(nste,center=FALSE,scale=(1/ds[k,]))) + log(prior[k])
    for(i in 1:nrow(xte))   {
      if(prob0[i]==0){

        for(k in 1:length(uniq)){
          discriminant1[,k] <- rowSums(scale(xte,center=FALSE,scale=(1/log(ds[k,])))) - rowSums(scale(nste,center=FALSE,scale=(1/ds[k,]))) + log(prior[k])
        }
        discriminant[i,]<-discriminant1[i,]
      }else{
        for(k in 1:length(uniq)){
          dstar = ds[k,]
          part2=nste[i,]*dstar
          part1=prob0[i]+(1-prob0[i])*exp(-part2)
          part1[part1==0]=1
          part2[part2==0]=1
          discriminant[i,k] <-sum(signx[i,]*log(part1))+sum(xte[i,]*(1-signx[i,])*log(dstar))-sum((1-signx[i,])*part2)+log(prior[k])
        }
      }

    }

    save <- list(ns=ns,nste=nste,ds=ds,discriminant=discriminant,ytehat=uniq[apply(discriminant,1,which.max)], alpha=alpha, x=x,y=y,xte=xte,alpha=alpha,type=type)
    class(save) <- "poicla"
    return(save)
  }
}
