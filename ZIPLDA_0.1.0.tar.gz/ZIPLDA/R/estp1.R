#estimate probablity of 0 with Logist regression

estp1<-function(x,testx){
  G<-length(x[1,])
  lib<-rowSums(x)
  x1<-t(x)
  testx1<-t(testx)
  librep<-rep(lib,rep(G,length(lib)))/mean(lib)
  x2<-as.vector(x1)
  testx2<-as.vector(testx1)

  y<-x2
  y[y!=0]<-1
  xreg<-cbind(y,librep,x2)
  glm.out<-glm(y~ librep+ x2,family=binomial("logit"),data=data.frame(xreg))
  summary(glm.out)


  coef<-as.matrix(glm.out$coefficients)
  inter<-rep(1,G)
  libsize<-rep(sum(x1[,1]),G)/mean(lib)
  estx1<-cbind(inter,libsize,x1[,1])
  p<-exp(estx1%*% coef)/(1+exp(estx1%*% coef))


  estx1[1:2,]%*%coef

  dim(estx1)

  dim(xreg[1:5,])
  num0<-apply(x==0,1,sum)
  probp<-apply(exp(-x),1,sum)-num0
  p<-(num0-probp)/(G-probp)
  p[num0<probp]<-0
  return(p)
}
